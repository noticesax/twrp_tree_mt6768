#!/sbin/sh

dd if=/dev/block/mapper/product of=/sdcard/product.img
dd if=/dev/block/mapper/vendor of=/sdcard/vendor.img